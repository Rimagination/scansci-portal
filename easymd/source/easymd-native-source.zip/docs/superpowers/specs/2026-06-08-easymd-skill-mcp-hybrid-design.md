# easymd Web 与 Skill 双产品设计

日期：2026-06-08

## 背景

参考 `sakuraoxo-clio/wechat-publisher` 后，easymd 要学习的不是单个发布脚本，而是一种产品组织方式：Agent 有自己的 Skill 工作流、组件资料包和交付标准；确定性工具只负责把可验证的转换做好。

上一版设计已经把 `/mcp`、`/docs/skill`、`/docs/mcp` 和 `skills/easymd/SKILL.md` 对齐到 “Skill + MCP 混合版”。新的产品判断是：**网站和 Skill 应该看作两个产品**。它们可以共享样式、主题、组件规范和渲染能力，但不应该互相降级为对方的说明页。

## 产品边界

| 产品 | 面向用户 | 核心价值 | 不负责 |
| --- | --- | --- | --- |
| easymd Web | 普通用户、内容创作者 | 可视化编辑 Markdown、预览主题、复制到公众号/知乎/富文本编辑器 | 不承担 Agent 文章策划工作 |
| easymd Skill | Claude、Codex 等 Agent | 理解文章、设计结构、选择组件、生成 SVG 信息图、交付精排 HTML | 不依赖网站 UI，不承诺自动发布 |
| easymd MCP | Agent 和工具链 | 提供 `render`、`parse`、`lint`、`extract` 等确定性能力 | 不表达产品流程，不代替 Skill 判断 |

## 要学习的优点

来自 `wechat-publisher` 的可借鉴点：

- Skill 不是 API 文档，而是 Agent 工作说明。
- Skill 有自己的 `references/` 资料包，Agent 可以读组件库和模板完成文章设计。
- 支持“只排版、不发草稿箱”的低门槛路径。
- 进阶发布能力需要凭证、白名单和接口权限，应明确放到非第一版范围。
- 正式文章优先组件化精排：导读卡、章节标题、callout、金句框、步骤、对比表、SVG 信息图。
- 输出目标是“可复制到公众号编辑器的 HTML”，不是网站截图。

easymd 对应落地：

- Skill 第一版聚焦文章制作和 HTML 交付，不接入公众号草稿箱。
- Skill 自带 `references/components.md`、`references/article-template.html`、`references/delivery-checklist.md`。
- MCP 继续提供确定性转换，供 Skill 在需要时调用。
- Web 保持可视化编辑器产品定位，同时在 `/docs/skill` 展示 Skill 安装和资料包。

## 目标

- 明确 Web、Skill、MCP 三者边界，并用测试守住。
- 把 `skills/easymd/SKILL.md` 从“工具调用说明”升级为“Agent 文章排版产品入口”。
- 为 Skill 增加组件化精排资料包，让 Agent 不依赖网站 UI 也能完成公众号文章。
- 在网站文档页展示产品边界、Skill 资料包和 MCP 工具。
- 保持第一版不触碰微信凭证流、草稿箱发布和自动发布。

## 非目标

- 不在第一版加入 `draft/add` 或公众号草稿箱写入。
- 不要求用户配置 `WECHAT_APP_ID`、`WECHAT_APP_SECRET` 或公网 IP 白名单。
- 不恢复旧 REST API 文档或已移除平台适配。
- 不把 easymd Web 改成 Skill 的运行界面。
- 不把 Skill 降级成“打开网站再操作”的兜底说明。

## Skill 设计

`skills/easymd/SKILL.md` 应保持短而明确：

- 开头声明网站和 Skill 是两个产品。
- 说明 Web、Skill、MCP 三者边界。
- 要求正式文章排版前读取 `references/` 资料包。
- 默认使用 MCP 做确定性转换；公众号精排时可在 MCP 输出基础上二次组织组件 HTML。
- 没有 MCP 时仍能手写可复制 HTML，而不是停止工作。
- 明确不承诺公众号草稿箱发布。

Skill 资料包：

- `references/components.md`：组件化精排组件库，包含组件用途、HTML 示例和 SVG 信息图规范。
- `references/article-template.html`：独立可复制的文章 HTML 模板。
- `references/delivery-checklist.md`：交付前检查边界、内容、视觉和技术风险。

## MCP 设计

`/mcp` 保持为共享能力层，暴露四个确定性工具：

| 工具 | 用途 | 主要消费者 |
| --- | --- | --- |
| `render` | Markdown 转平台 HTML | Skill、其他 Agent、自动化脚本 |
| `parse` | HTML 转 Markdown | 内容迁移、清理富文本 |
| `lint` | 修复 Markdown 格式 | Skill 前处理、Web 编辑辅助 |
| `extract` | 提取纯文本 | 摘要、字数统计、二次分析 |

MCP 工具描述应该避免把自己包装成完整产品。它只提供可测试能力，文章策划、组件选择和交付判断属于 Skill。

## Web 文档设计

`/docs/skill`：

- 展示真实安装命令 `npx skills add Rimagination/easymd --skill easymd`。
- 说明“两个产品，一套能力”：Web 给人用，Skill 给 Agent 用，MCP 提供确定性工具。
- 展示 Web、Skill、MCP 边界。
- 展示 Skill 资料包列表。
- 展示当前 `SKILL.md`，便于复制和审查。

`/docs/mcp`：

- 展示 Server 地址和客户端配置。
- 展示 `render`、`parse`、`lint`、`extract` 工具列表。
- 明确 MCP 是共享能力层，不代表 Web 或 Skill 本身。

## 测试范围

- `src/lib/agent-docs/easymd.test.ts` 检查：
  - 安装命令是真实仓库。
  - 平台只包含 `html`、`wechat`、`zhihu`。
  - 产品边界包含 `web`、`skill`、`mcp`。
  - Skill references 三个文件存在且内容非空。
  - `SKILL.md` 包含“网站和 Skill 是两个产品”、`references/components.md`、`组件化精排`、`默认使用 MCP`。
  - `SKILL.md` 不再出现旧平台、旧 REST API 或 curl 示例。
- MCP 既有协议测试继续保证工具列表和 `render` 调用可用。
- 文档页依赖同一份 `agent-docs` 元数据，减少文案漂移。

## 风险与处理

- Skill references 过长会占用 Agent 上下文。处理方式：`SKILL.md` 只列读取顺序，细节放进按需读取的 reference 文件。
- Web 文档页可能把 Skill 讲成附属功能。处理方式：文案固定为“两个产品，一套能力”。
- MCP 被误解为完整发布产品。处理方式：`/docs/mcp` 明确它是共享能力层。
- 公众号草稿箱发布诱惑很强，但第一版不做。后续若做，应作为独立“publisher”能力设计，并显式处理凭证、IP 白名单和权限风险。

## 第一版交付

完成后，用户应该能：

1. 在网站看到 Web、Skill、MCP 的边界。
2. 安装 easymd Skill，并让 Agent 读取组件库和模板。
3. 让 Agent 把 Markdown 或原文做成公众号可复制 HTML。
4. 让 Agent 按需生成内联 SVG 信息图。
5. 使用 MCP 完成确定性转换。
6. 在没有 MCP 时，仍得到基于 Skill references 的手写 HTML 交付。
