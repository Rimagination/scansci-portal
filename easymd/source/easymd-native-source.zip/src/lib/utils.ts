import type { ClassValue } from 'clsx'
import { clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Keep tool dialogs and menus in the same themed workspace when hosted by ScanSci.
export function getToolPortalContainer() {
  return typeof document === 'undefined' ? undefined : document.getElementById('easymdRoot') ?? undefined
}
