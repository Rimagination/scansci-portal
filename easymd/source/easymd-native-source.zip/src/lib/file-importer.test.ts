import { describe, expect, it } from 'vitest'
import { findLocalImageFile, rewriteLocalImageReferences } from './file-importer'

function makeImage(name: string, relativePath?: string): File {
  const file = new File(['image'], name, { type: 'image/png' })
  if (relativePath) {
    Object.defineProperty(file, 'webkitRelativePath', { value: relativePath })
  }
  return file
}

describe('local image import helpers', () => {
  it('matches relative paths before falling back to a unique basename', () => {
    const nested = makeImage('figure.png', 'draft/assets/figure.png')
    const other = makeImage('other.png')

    expect(findLocalImageFile('assets/figure.png', [nested, other])).toBe(nested)
    expect(findLocalImageFile('./other.png?cache=1', [nested, other])).toBe(other)
    expect(findLocalImageFile('C:\\draft\\other.png', [nested, other])).toBe(other)
    expect(findLocalImageFile('https://example.com/figure.png', [nested, other])).toBeNull()
  })

  it('leaves ambiguous basenames unchanged', () => {
    const first = makeImage('figure.png', 'one/figure.png')
    const second = makeImage('figure.png', 'two/figure.png')

    expect(findLocalImageFile('figure.png', [first, second])).toBeNull()
  })

  it('rewrites Markdown and HTML references while preserving remote images', async () => {
    const figure = makeImage('figure.png')
    const markdown = [
      '![figure](assets/figure.png "source")',
      '<img alt="figure" src="figure.png">',
      '![remote](https://example.com/remote.png)',
    ].join('\n')

    const result = await rewriteLocalImageReferences(
      markdown,
      [figure],
      async file => `/uploads/${file.name}`,
    )

    expect(result.markdown).toContain('![figure](/uploads/figure.png "source")')
    expect(result.markdown).toContain('src="/uploads/figure.png"')
    expect(result.markdown).toContain('https://example.com/remote.png')
    expect(result.replaced).toBe(2)
    expect(result.missing).toEqual([])
  })
})
