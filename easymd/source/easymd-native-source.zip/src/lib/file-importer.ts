import { toast } from 'sonner'
import { useFilesStore } from '@/stores/files'

export interface ImportedFile {
  name: string
  content: string
}

export interface ImportFilesAsNewTabsOptions {
  prepareContent?: (file: File, content: string) => Promise<string>
}

export interface RewriteLocalImageReferencesResult {
  markdown: string
  replaced: number
  missing: string[]
}

const MARKDOWN_IMAGE_PATTERN = /(!\[[^\]]*\]\([ \t]*)(<[^>\n]+>|[^)\s]+)([ \t]+(?:"[^"\n]*"|'[^'\n]*'))?([ \t]*\))/g
const HTML_IMAGE_PATTERN = /(<img\b[^>]+\bsrc\s*=\s*)(["'])([^"']+)(\2)/gi

function normalizeImageSource(source: string): string {
  let normalized = source.trim()
  if (normalized.startsWith('<') && normalized.endsWith('>')) {
    normalized = normalized.slice(1, -1).trim()
  }

  normalized = normalized.split(/[?#]/, 1)[0]
  try {
    normalized = decodeURIComponent(normalized)
  }
  catch {
    // Keep the original path when it contains an incomplete escape sequence.
  }

  return normalized
    .replaceAll('\\', '/')
    .replace(/^\.\//, '')
    .replace(/\/+/g, '/')
    .toLowerCase()
}

function isExternalImageSource(source: string): boolean {
  const raw = source.trim()
  const normalized = raw.toLowerCase()
  const isWindowsPath = /^[a-z]:[\\/]/i.test(raw)
  const isLocalFileUrl = /^file:\/\/(?:\/|[a-z]:)/i.test(raw)
  return (
    !normalized
    || normalized.startsWith('#')
    || normalized.startsWith('/')
    || normalized.startsWith('data:')
    || normalized.startsWith('blob:')
    || normalized.startsWith('//')
    || (!isWindowsPath && !isLocalFileUrl && /^[a-z][a-z\d+.-]*:/i.test(normalized))
  )
}

function getFilePaths(file: File): string[] {
  const relativePath = (file as File & { webkitRelativePath?: string }).webkitRelativePath
  return [relativePath, file.name]
    .filter((path): path is string => Boolean(path))
    .map(normalizeImageSource)
}

export function findLocalImageFile(source: string, files: File[]): File | null {
  if (isExternalImageSource(source)) {
    return null
  }

  const target = normalizeImageSource(source)
  if (!target) {
    return null
  }

  const exactMatches = files.filter((file) => {
    const paths = getFilePaths(file)
    return paths.some(path => path === target || path.endsWith(`/${target}`))
  })
  const uniqueExactMatches = [...new Set(exactMatches)]
  if (uniqueExactMatches.length === 1) {
    return uniqueExactMatches[0]
  }
  if (uniqueExactMatches.length > 1) {
    return null
  }

  const basename = target.split('/').pop()
  if (!basename) {
    return null
  }

  const basenameMatches = files.filter((file) => {
    const paths = getFilePaths(file)
    return paths.some(path => path.split('/').pop() === basename)
  })
  const uniqueBasenameMatches = [...new Set(basenameMatches)]
  return uniqueBasenameMatches.length === 1 ? uniqueBasenameMatches[0] : null
}

export async function rewriteLocalImageReferences(
  markdown: string,
  imageFiles: File[],
  resolveImage: (file: File) => Promise<string>,
): Promise<RewriteLocalImageReferencesResult> {
  const replacements = new Map<string, string>()
  const missing = new Set<string>()
  const resolving = new Map<File, Promise<string>>()

  async function resolveSource(source: string): Promise<void> {
    if (replacements.has(source) || missing.has(source) || isExternalImageSource(source)) {
      return
    }

    const file = findLocalImageFile(source, imageFiles)
    if (!file) {
      missing.add(normalizeImageSource(source))
      return
    }

    let pending = resolving.get(file)
    if (!pending) {
      pending = resolveImage(file)
      resolving.set(file, pending)
    }

    try {
      const url = await pending
      if (url) {
        replacements.set(source, url)
      }
      else {
        missing.add(normalizeImageSource(source))
      }
    }
    catch {
      missing.add(normalizeImageSource(source))
    }
  }

  for (const match of markdown.matchAll(MARKDOWN_IMAGE_PATTERN)) {
    await resolveSource(match[2])
  }
  for (const match of markdown.matchAll(HTML_IMAGE_PATTERN)) {
    await resolveSource(match[3])
  }

  let replaced = 0
  let result = markdown.replace(
    MARKDOWN_IMAGE_PATTERN,
    (full: string, prefix: string, source: string, title: string | undefined, suffix: string) => {
      const url = replacements.get(source)
      if (!url) {
        return full
      }

      replaced += 1
      const wrappedUrl = source.trim().startsWith('<') ? `<${url}>` : url
      return `${prefix}${wrappedUrl}${title || ''}${suffix}`
    },
  )
  result = result.replace(
    HTML_IMAGE_PATTERN,
    (full: string, prefix: string, quote: string, source: string) => {
      const url = replacements.get(source)
      if (!url) {
        return full
      }

      replaced += 1
      return `${prefix}${quote}${url}${quote}`
    },
  )

  return {
    markdown: result,
    replaced,
    missing: [...missing].filter(Boolean),
  }
}

export async function parseFileToMarkdown(file: File): Promise<ImportedFile | null> {
  if (file.type === 'text/markdown' || file.name.endsWith('.md')) {
    const content = await file.text()
    const name = file.name.endsWith('.md') ? file.name : `${file.name}.md`
    return { name, content }
  }

  if (file.type === 'text/html') {
    const html = await file.text()
    const { markdown } = await import('@/lib/markdown/browser')
    const { result: content } = await markdown.parse({ html })
    const baseName = file.name.replace(/\.html?$/i, '')
    return { name: `${baseName}.md`, content }
  }

  return null
}

export async function importFilesAsNewTabs(
  files: File[],
  options: ImportFilesAsNewTabsOptions = {},
): Promise<string | null> {
  const { createFile, switchFile } = useFilesStore.getState()
  let lastCreatedId: string | null = null

  for (const file of files) {
    try {
      const parsed = await parseFileToMarkdown(file)
      if (parsed) {
        const content = options.prepareContent
          ? await options.prepareContent(file, parsed.content)
          : parsed.content
        const id = await createFile(parsed.name, content)
        lastCreatedId = id
        toast.success(`导入成功: ${parsed.name}`)
      }
    }
    catch (error) {
      console.error('Import error:', error)
      toast.error(`导入失败: ${file.name}`)
    }
  }

  if (lastCreatedId) {
    await switchFile(lastCreatedId)
  }

  return lastCreatedId
}

export function isTextFile(file: File): boolean {
  return (
    file.type === 'text/markdown'
    || file.name.endsWith('.md')
    || file.type === 'text/html'
  )
}

export function isImageFile(file: File): boolean {
  return file.type.startsWith('image/')
}
