import { afterEach, describe, expect, it, vi } from 'vitest'
import { consumeWechatOAuthState, createWechatAuthorizationUrl, getWechatCallbackUrl, getWechatComponentCallbackUrl } from './platform'

const persistenceMock = vi.hoisted(() => ({
  consumeWechatRecord: vi.fn(async (key, validate) => {
    const record = await persistenceMock.readWechatRecord(key)
    if (!record || !validate(record)) return undefined
    await persistenceMock.deleteWechatRecord(key)
    return record
  }),
  deleteWechatRecord: vi.fn(),
  isWechatStateStorageConfigured: vi.fn(() => true),
  readWechatRecord: vi.fn(),
  wechatObjectKeys: {
    account: (browserId: string) => `account:${browserId}`,
    component: () => 'component',
    oauthState: (state: string) => `oauth:${state}`,
  },
  writeWechatRecord: vi.fn(),
}))

vi.mock('./persistence', () => persistenceMock)
const configuration = vi.hoisted(() => ({
  VITE_APP_URL: 'https://www.scansci.com/easymd/',
  WECHAT_COMPONENT_APPID: 'component-app',
  WECHAT_COMPONENT_APPSECRET: 'component-secret',
  WECHAT_COMPONENT_TOKEN: 'component-token',
  WECHAT_COMPONENT_ENCODING_AES_KEY: 'encoding-key',
}))
vi.mock('@/env', () => ({ env: configuration }))

afterEach(() => {
  vi.clearAllMocks()
  vi.unstubAllGlobals()
})

describe('wechat OAuth state', () => {
  it('puts the browser-bound state inside the configured callback URL', async () => {
    persistenceMock.readWechatRecord.mockResolvedValue({ componentAccessToken: 'component-token', componentAccessTokenExpiresAt: Date.now() + 60_000 })
    vi.stubGlobal('fetch', vi.fn(async () => Response.json({ pre_auth_code: 'pre-auth' })))
    const request = new Request('https://untrusted.example/api/wechat/authorize')
    const authorization = new URL(await createWechatAuthorizationUrl(request, 'browser-a', '/easymd/'))
    const callback = new URL(authorization.searchParams.get('redirect_uri')!)
    const state = callback.searchParams.get('state')
    expect(callback.origin + callback.pathname).toBe('https://www.scansci.com/easymd/api/wechat/callback')
    expect(state).toMatch(/^[A-Za-z0-9_-]{32}$/)
    expect(authorization.searchParams.get('auth_type')).toBe('1')
    expect(persistenceMock.writeWechatRecord).toHaveBeenCalledWith(`oauth:${state}`, expect.objectContaining({ browserId: 'browser-a', returnTo: '/easymd/' }))
    expect(getWechatComponentCallbackUrl(request)).toBe('https://www.scansci.com/easymd/api/wechat/component')
    expect(getWechatCallbackUrl(request)).toBe(callback.origin + callback.pathname)
  })

  it('does not consume a state created for another browser session', async () => {
    const record = {
      browserId: 'browser-a',
      createdAt: new Date().toISOString(),
      expiresAt: Date.now() + 60_000,
      returnTo: '/',
    }
    persistenceMock.readWechatRecord.mockResolvedValue(record)

    expect(await consumeWechatOAuthState('state-a', 'browser-b')).toBeUndefined()
    expect(persistenceMock.deleteWechatRecord).not.toHaveBeenCalled()

    expect(await consumeWechatOAuthState('state-a', 'browser-a')).toEqual(record)
    expect(persistenceMock.deleteWechatRecord).toHaveBeenCalledWith('oauth:state-a')
  })
})
