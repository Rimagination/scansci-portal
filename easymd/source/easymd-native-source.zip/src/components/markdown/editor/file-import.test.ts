import type { TransactionSpec } from '@codemirror/state'
import type { EditorView } from '@codemirror/view'
import { EditorState } from '@codemirror/state'
import { toast } from 'sonner'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { uploadImage } from '@/services/upload'
import { importFilesToEditor } from './file-import'

vi.mock('@/services/upload', () => ({ uploadImage: vi.fn() }))
vi.mock('sonner', () => ({ toast: { loading: vi.fn(), success: vi.fn(), error: vi.fn(), warning: vi.fn() } }))

function editor() {
  let state = EditorState.create({ doc: 'before\nafter', selection: { anchor: 7 } })
  const view = {
    get state() { return state },
    hasFocus: true,
    dispatch: vi.fn((spec: TransactionSpec) => { state = state.update(spec).state }),
  }
  return view as unknown as EditorView
}

describe('image import', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.spyOn(console, 'error').mockImplementation(() => {})
  })
  afterEach(() => vi.restoreAllMocks())

  it('keeps the text and cursor unchanged when upload fails', async () => {
    const view = editor()
    vi.mocked(uploadImage).mockRejectedValueOnce(new Error('图片保存失败'))
    await importFilesToEditor(view, [new File(['png'], 'image.png', { type: 'image/png' })])
    expect(view.state.doc.toString()).toBe('before\nafter')
    expect(view.state.selection.main.head).toBe(7)
    expect(view.dispatch).not.toHaveBeenCalled()
    expect(toast.error).toHaveBeenCalledWith('图片保存失败', expect.any(Object))
  })

  it('inserts the returned image URL at the current cursor', async () => {
    const view = editor()
    vi.mocked(uploadImage).mockResolvedValueOnce({ url: '/easymd/uploads/images/figure.png' })
    await importFilesToEditor(view, [new File(['png'], 'image.png', { type: 'image/png' })])
    expect(view.state.doc.toString()).toBe('before\n\n![image.png](/easymd/uploads/images/figure.png)\nafter')
    expect(toast.success).toHaveBeenCalledOnce()
  })

  it('continues a batch after a failed image without inserting a placeholder', async () => {
    const view = editor()
    vi.mocked(uploadImage).mockRejectedValueOnce(new Error('Offline')).mockResolvedValueOnce({ url: '/good.png' })
    await importFilesToEditor(view, ['bad.png', 'good.png'].map(name => new File(['png'], name, { type: 'image/png' })))
    expect(view.state.doc.toString()).toBe('before\n\n![good.png](/good.png)\nafter')
    expect(toast.error).toHaveBeenCalledOnce()
    expect(toast.success).toHaveBeenCalledOnce()
  })
})
