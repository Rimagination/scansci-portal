import { createFileRoute } from '@tanstack/react-router'
import { wechatDraftMiddleware } from '@/lib/middleware/wechat-draft'
import { handlers } from '@/lib/wechat-draft/http/authorize'

export const Route = createFileRoute('/api/wechat/authorize')({
  server: { middleware: [wechatDraftMiddleware], handlers },
})
