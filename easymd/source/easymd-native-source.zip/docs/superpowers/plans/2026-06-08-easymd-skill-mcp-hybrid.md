# easymd Web 与 Skill 双产品 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make easymd treat Web and Skill as separate products while sharing style references and MCP conversion tools.

**Architecture:** Keep Agent-facing product metadata in `src/lib/agent-docs/easymd.ts`, keep Skill instructions and references under `skills/easymd`, and let `/docs/skill` and `/docs/mcp` render from the shared metadata. MCP remains the deterministic tool layer; Skill owns article composition and delivery judgment.

**Tech Stack:** TypeScript, TanStack Start routes, React 19, Vitest, Markdown Skill files, MCP TypeScript SDK.

---

## File Structure

- Modify `src/lib/agent-docs/easymd.ts`: add product-boundary and Skill reference metadata.
- Modify `src/lib/agent-docs/easymd.test.ts`: assert the new product boundary and reference pack.
- Modify `skills/easymd/SKILL.md`: rewrite as the Agent-facing article production product.
- Create `skills/easymd/references/components.md`: component library for Agent composition.
- Create `skills/easymd/references/article-template.html`: standalone HTML skeleton for copied article output.
- Create `skills/easymd/references/delivery-checklist.md`: final QA checklist for Agent delivery.
- Modify `src/routes/_layout.docs.skill.tsx`: show install command, product boundary, and reference pack.
- Modify `src/routes/_layout.docs.mcp.tsx`: state that MCP is the shared deterministic capability layer.
- Modify `docs/superpowers/specs/2026-06-08-easymd-skill-mcp-hybrid-design.md`: preserve the product decision for future work.
- Modify this plan file as implementation proceeds.

## Task 1: Guard The Product Boundary With Tests

**Files:**
- Modify: `src/lib/agent-docs/easymd.test.ts`

- [x] **Step 1: Write the failing test**

Add imports for `EASYMD_PRODUCT_BOUNDARY` and `EASYMD_SKILL_REFERENCES`, then add tests that expect:

```ts
expect(EASYMD_PRODUCT_BOUNDARY.map(item => item.id)).toEqual(['web', 'skill', 'mcp'])
expect(EASYMD_SKILL_REFERENCES.map(reference => reference.path)).toEqual([
  'skills/easymd/references/components.md',
  'skills/easymd/references/article-template.html',
  'skills/easymd/references/delivery-checklist.md',
])
expect(skillMarkdown).toContain('网站和 Skill 是两个产品')
expect(skillMarkdown).toContain('references/components.md')
expect(skillMarkdown).toContain('组件化精排')
expect(skillMarkdown).toContain('默认使用 MCP')
```

- [x] **Step 2: Run the test and verify RED**

Run:

```bash
pnpm test src/lib/agent-docs/easymd.test.ts
```

Expected: FAIL because product-boundary exports and reference files do not exist, and `SKILL.md` does not contain the new product-boundary language.

## Task 2: Add Agent Product Metadata And Skill References

**Files:**
- Modify: `src/lib/agent-docs/easymd.ts`
- Modify: `skills/easymd/SKILL.md`
- Create: `skills/easymd/references/components.md`
- Create: `skills/easymd/references/article-template.html`
- Create: `skills/easymd/references/delivery-checklist.md`

- [x] **Step 1: Add shared product-boundary metadata**

Add:

```ts
export const EASYMD_PRODUCT_BOUNDARY = [
  {
    id: 'web',
    title: 'easymd Web',
    role: '普通用户使用的可视化 Markdown 排版工作台，负责编辑、预览、主题调试和复制到富文本编辑器。',
  },
  {
    id: 'skill',
    title: 'easymd Skill',
    role: 'Agent 使用的公众号文章制作产品，负责理解文章意图、选择组件、生成 SVG 信息图和交付精排 HTML。',
  },
  {
    id: 'mcp',
    title: 'easymd MCP',
    role: '确定性能力层，供 Skill 或其他 Agent 调用 render、parse、lint、extract 等可测试工具。',
  },
] as const
```

- [x] **Step 2: Add Skill reference metadata**

Add:

```ts
export const EASYMD_SKILL_REFERENCES = [
  {
    path: 'skills/easymd/references/components.md',
    title: '组件化精排组件库',
    description: '给 Agent 使用的公众号组件、适用场景和组合规则。',
  },
  {
    path: 'skills/easymd/references/article-template.html',
    title: '文章 HTML 模板',
    description: '给 Agent 生成独立公众号 HTML 时使用的基础结构和样式变量。',
  },
  {
    path: 'skills/easymd/references/delivery-checklist.md',
    title: '交付检查清单',
    description: '给 Agent 在交付前检查标题、图片、SVG、表格和复制风险。',
  },
] as const
```

- [x] **Step 3: Rewrite `SKILL.md` as a product entry**

The file must include:

```md
easymd 网站和 Skill 是两个产品。网站是给普通用户看的可视化编辑器；Skill 是给 Agent 用的文章制作产品。
```

It must instruct Agent to read:

```md
1. `references/components.md`
2. `references/article-template.html`
3. `references/delivery-checklist.md`
```

- [x] **Step 4: Create the three reference files**

Create component guidance, HTML skeleton, and final delivery checklist. Each file must contain its own title so the metadata test can verify it.

- [x] **Step 5: Run the focused test and verify GREEN**

Run:

```bash
pnpm test src/lib/agent-docs/easymd.test.ts
```

Expected: PASS.

## Task 3: Update Website Documentation Pages

**Files:**
- Modify: `src/routes/_layout.docs.skill.tsx`
- Modify: `src/routes/_layout.docs.mcp.tsx`

- [x] **Step 1: Render the product boundary on `/docs/skill`**

Import:

```ts
import {
  EASYMD_PRODUCT_BOUNDARY,
  EASYMD_SKILL_INSTALL_COMMAND,
  EASYMD_SKILL_REFERENCES,
} from '@/lib/agent-docs/easymd'
```

Render `EASYMD_PRODUCT_BOUNDARY` as compact bordered items below the install card.

- [x] **Step 2: Render the Skill reference pack on `/docs/skill`**

Render `EASYMD_SKILL_REFERENCES` with title, path, and description so users can see that Skill has its own materials.

- [x] **Step 3: Clarify `/docs/mcp`**

Add this copy above the server URL:

```tsx
<p className="text-xs text-muted-foreground">
  MCP 是 easymd Web 和 easymd Skill 共用的确定性能力层，不代表其中任一产品本身。
</p>
```

## Task 4: Keep The Existing MCP Contract Green

**Files:**
- Test: `src/lib/agent-docs/easymd.test.ts`
- Test: `src/lib/mcp/easymd-server.test.ts`

- [x] **Step 1: Run focused Agent metadata tests**

Run:

```bash
pnpm test src/lib/agent-docs/easymd.test.ts
```

Expected: PASS.

- [x] **Step 2: Run MCP server tests**

Run:

```bash
pnpm test src/lib/mcp/easymd-server.test.ts
```

Expected: PASS. If this fails from unrelated MCP transport work already in the tree, inspect before changing product-boundary files.

## Task 5: Full Verification

**Files:**
- All modified files.

- [x] **Step 1: Run focused tests**

Run:

```bash
pnpm test src/lib/agent-docs/easymd.test.ts src/lib/mcp/easymd-server.test.ts
```

Expected: PASS.

- [x] **Step 2: Run typecheck**

Run:

```bash
pnpm typecheck
```

Expected: PASS.

- [x] **Step 3: Inspect product-boundary diff**

Run:

```bash
git diff -- src/lib/agent-docs/easymd.ts src/lib/agent-docs/easymd.test.ts skills/easymd/SKILL.md skills/easymd/references src/routes/_layout.docs.skill.tsx src/routes/_layout.docs.mcp.tsx docs/superpowers/specs/2026-06-08-easymd-skill-mcp-hybrid-design.md docs/superpowers/plans/2026-06-08-easymd-skill-mcp-hybrid.md
```

Expected: diff only contains the Web/Skill product-boundary work and the Skill reference pack.
