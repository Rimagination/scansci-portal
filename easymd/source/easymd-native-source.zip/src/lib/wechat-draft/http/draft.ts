import * as z from 'zod'
import { getWechatAccountContext } from '@/lib/wechat-draft/account'
import { getWechatAuthorizer, getWechatAuthorizerAccessToken, isWechatPlatformConfigured } from '@/lib/wechat-draft/platform'
import { publishWechatDraft, readLimitedBytes, WechatDraftError, wechatDraftLimits } from '@/lib/wechat-draft/service'

const draftFieldsSchema = z.object({
  author: z.string().trim().max(64).default(''),
  coverMediaId: z.string().trim().max(512).default(''),
  digest: z.string().trim().max(120).default(''),
  html: z.string().trim().min(1).max(wechatDraftLimits.maxHtmlInputChars),
  needOpenComment: z.enum(['0', '1']).default('0'),
  onlyFansCanComment: z.enum(['0', '1']).default('0'),
  showCoverPic: z.enum(['0', '1']).default('0'),
  sourceUrl: z.string().trim().max(2048).default(''),
  title: z.string().trim().min(1).max(64),
})

function readFormString(formData: FormData, name: string): string {
  const value = formData.get(name)
  return typeof value === 'string' ? value : ''
}

function errorResponse(error: unknown): Response {
  if (error instanceof z.ZodError) {
    return Response.json({ error: '草稿参数不符合要求。' }, { status: 400 })
  }
  if (error instanceof WechatDraftError) {
    return Response.json({ error: error.message }, { status: error.status })
  }
  console.error('WeChat draft publish error.')
  return Response.json({ error: '同步草稿箱失败，请稍后重试。' }, { status: 500 })
}

export const handlers = {
  POST: async ({ request }: { request: Request }) => {
    if (!isWechatPlatformConfigured()) {
      return Response.json({ error: '公众号连接服务尚未配置，请联系 easymd 管理员。' }, { status: 503 })
    }

    try {
      const context = await getWechatAccountContext(request)
      if (!context.browserId || !context.record) {
        return Response.json({ error: '请先连接你的公众号。' }, { status: 401 })
      }

      const contentLength = Number(request.headers.get('content-length'))
      if (Number.isFinite(contentLength) && contentLength > wechatDraftLimits.maxRequestBytes) {
        return Response.json({ error: '请求内容过大，请减少封面或正文内容。' }, { status: 413 })
      }

      const bytes = await readLimitedBytes(request, wechatDraftLimits.maxRequestBytes, new WechatDraftError('请求内容过大，请减少封面或正文内容。', 413))
      const formData = await new Response(bytes, { headers: { 'Content-Type': request.headers.get('Content-Type') || '' } }).formData()
      const fields = draftFieldsSchema.parse({
        author: readFormString(formData, 'author'),
        coverMediaId: readFormString(formData, 'coverMediaId'),
        digest: readFormString(formData, 'digest'),
        html: readFormString(formData, 'html'),
        needOpenComment: readFormString(formData, 'needOpenComment') || '0',
        onlyFansCanComment: readFormString(formData, 'onlyFansCanComment') || '0',
        showCoverPic: readFormString(formData, 'showCoverPic') || '0',
        sourceUrl: readFormString(formData, 'sourceUrl'),
        title: readFormString(formData, 'title'),
      })

      const coverValue = formData.get('cover')
      const cover = coverValue instanceof Blob && coverValue.size > 0 ? coverValue : undefined
      const coverFilename = coverValue && typeof coverValue === 'object' && 'name' in coverValue
        ? String(coverValue.name)
        : undefined

      const authorizerAccessToken = await getWechatAuthorizerAccessToken(context.browserId)
      const result = await publishWechatDraft({
        ...fields,
        cover,
        coverFilename,
        needOpenComment: fields.needOpenComment === '1',
        onlyFansCanComment: fields.onlyFansCanComment === '1',
        showCoverPic: fields.showCoverPic === '1',
      }, authorizerAccessToken, async () => {
        const active = await getWechatAuthorizer(context.browserId!)
        if (!active || active.authorizerAppId !== context.record!.authorizerAppId || active.connectionId !== context.record!.connectionId) {
          throw new WechatDraftError('公众号连接已更新，请重新打开同步窗口。', 401)
        }
      })

      return Response.json({
        contentBytes: result.contentBytes,
        contentChars: result.contentChars,
        coverMediaId: result.coverMediaId,
        draftMediaId: result.draftMediaId,
        imageCount: result.imageCount,
      })
    }
    catch (error) {
      return errorResponse(error)
    }
  },
}
