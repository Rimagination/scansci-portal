import { createFileRoute } from '@tanstack/react-router'
import { wechatDraftMiddleware } from '@/lib/middleware/wechat-draft'
import { handlers } from '@/lib/wechat-draft/http/draft'

export const Route = createFileRoute('/api/wechat/draft')({
  server: { middleware: [wechatDraftMiddleware], handlers },
})
