import { createFileRoute } from '@tanstack/react-router'
import { wechatDraftMiddleware } from '@/lib/middleware/wechat-draft'
import { handlers } from '@/lib/wechat-draft/http/callback'

export const Route = createFileRoute('/api/wechat/callback')({
  server: { middleware: [wechatDraftMiddleware], handlers },
})
