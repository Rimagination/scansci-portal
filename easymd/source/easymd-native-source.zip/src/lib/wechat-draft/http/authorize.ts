import { getOrCreateBrowserSession } from '@/lib/wechat-draft/browser-session'
import { createWechatAuthorizationUrl, getWechatAppUrl, isWechatPlatformConfigured } from '@/lib/wechat-draft/platform'

function redirectToApp(request: Request, error: string): Response {
  const url = getWechatAppUrl(request)
  url.searchParams.set('wechat_error', error)
  return Response.redirect(url, 302)
}

export const handlers = {
  GET: async ({ request }: { request: Request }) => {
    if (!isWechatPlatformConfigured()) {
      return redirectToApp(request, 'service_unavailable')
    }

    try {
      const session = getOrCreateBrowserSession(request)
      const returnTo = new URL(request.url).searchParams.get('returnTo')
      const authorizationUrl = await createWechatAuthorizationUrl(request, session.browserId, returnTo)
      const headers = new Headers({
        'Cache-Control': 'no-store',
        'Location': authorizationUrl,
      })
      if (session.setCookie) {
        headers.set('Set-Cookie', session.setCookie)
      }
      return new Response(null, { status: 302, headers })
    }
    catch {
      console.error('WeChat authorization start error.')
      return redirectToApp(request, 'service_unavailable')
    }
  },
}
