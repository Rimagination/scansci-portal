import { createMemoryHistory, createRootRoute, createRouter, Outlet, RouterProvider } from '@tanstack/react-router'
import { ThemeProvider } from 'next-themes'
import { createRoot } from 'react-dom/client'
import { Toaster } from '@/components/ui/sonner'
import { Route as WorkspaceRoute } from '@/routes/_layout'
import { Route as AboutRoute } from '@/routes/_layout.about'
import { Route as IndexRoute } from '@/routes/_layout.index'
import { Route as McpDocsRoute } from '@/routes/_layout.docs.mcp'
import { Route as SkillDocsRoute } from '@/routes/_layout.docs.skill'
import './styles.css'

function ScanSciEditor() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableColorScheme>
      <Outlet />
      <Toaster />
    </ThemeProvider>
  )
}

export function mountEasyMD(element: HTMLElement) {
  const rootRoute = createRootRoute({ component: ScanSciEditor })
  const workspace = WorkspaceRoute.update({ id: '/_layout', getParentRoute: () => rootRoute } as never)
  const routes = [
    IndexRoute.update({ id: '/', path: '/', getParentRoute: () => workspace } as never),
    AboutRoute.update({ id: '/about', path: '/about', getParentRoute: () => workspace } as never),
    McpDocsRoute.update({ id: '/docs/mcp', path: '/docs/mcp', getParentRoute: () => workspace } as never),
    SkillDocsRoute.update({ id: '/docs/skill', path: '/docs/skill', getParentRoute: () => workspace } as never),
  ]
  // Documentation uses dialogs inside the tool; portal navigation owns the browser history.
  const history = createMemoryHistory({ initialEntries: [window.location.pathname.startsWith('/easymd/') ? window.location.pathname : '/easymd/'] })
  const router = createRouter({ routeTree: rootRoute.addChildren([workspace.addChildren(routes)]), history, basepath: '/easymd' })
  const reactRoot = createRoot(element)
  reactRoot.render(<RouterProvider router={router} />)
}
