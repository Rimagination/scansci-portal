import { describe, expect, it } from 'vitest'
import { render } from './html'

describe('wechat render adapter', () => {
  it('converts external links to footnotes and removes href', async () => {
    const html = await render({
      markdown: '[示例](https://example.com)',
      platform: 'wechat',
    })

    expect(html).not.toContain('href="https://example.com"')
    expect(html).toContain('<span>示例</span>')
    expect(html).toMatch(/<sup[^>]*>\[1\]<\/sup>/)
    expect(html).toContain('参考资料')
    expect(html).toContain('https://example.com')
  })

  it('renders mp.weixin article links as numbered plain-text references', async () => {
    const html = await render({
      markdown: '[公众号](https://mp.weixin.qq.com/s/abc)',
      platform: 'wechat',
    })

    expect(html).not.toMatch(/<a\b/)
    expect(html).toContain('footnote-ref')
    expect(html).toContain('https://mp.weixin.qq.com/s/abc')
    expect(html).toContain('参考资料')
  })

  it('keeps a manually cited Markdown draft as one plain-text reference list', async () => {
    const html = await render({
      markdown: '这项结果<sup>[1]</sup>，后文再次引用<sup>[1]</sup>。\n\n## 参考资料\n\n1. 作者. 论文标题. 2026. https://example.com/paper',
      markdownStyle: 'thu-classic',
      platform: 'wechat',
    })

    expect(html).not.toMatch(/<a\b/)
    expect(html.match(/class="footnote-ref"/g)).toHaveLength(2)
    expect(html.match(/\[1\]/g)).toHaveLength(2)
    expect(html.match(/https:\/\/example\.com\/paper/g)).toHaveLength(1)
    expect(html).not.toContain('footnotes')
    expect(html).toContain('参考资料')
  })

  it('footnotes mailto and tel links', async () => {
    const html = await render({
      markdown: '[邮件](mailto:test@example.com) [电话](tel:123)',
      platform: 'wechat',
    })

    expect(html).not.toContain('href="mailto:test@example.com"')
    expect(html).not.toContain('href="tel:123"')
    expect(html).toContain('mailto:test@example.com')
    expect(html).toContain('tel:123')
    expect(html).toContain('参考资料')
  })

  it('keeps nested lists valid', async () => {
    const html = await render({
      markdown: '- a\n  - b',
      platform: 'wechat',
    })

    expect(html).not.toMatch(/<\/li>\s*<(ul|ol)>/)
  })

  it('renders task list checkboxes as symbols', async () => {
    const html = await render({
      markdown: '- [x] done\n- [ ] todo',
      platform: 'wechat',
    })

    expect(html).toContain('☑')
    expect(html).toContain('☐')
    expect(html).not.toContain('<input')
  })

  it('wraps tables with overflow container', async () => {
    const html = await render({
      markdown: '|a|b|\n|---|---|\n|1|2|',
      platform: 'wechat',
    })

    expect(html).toMatch(/<figure[^>]*class="figure-table"[^>]*>\s*<table/)
  })

  it('converts code block newlines to br elements', async () => {
    const html = await render({
      markdown: '```js\nconst a = 1\nconst b = 2\n```',
      platform: 'wechat',
    })

    expect(html).toContain('<br>')
    expect(html).not.toMatch(/<code[^>]*>[^<]*\n/)
  })

  it('converts leading spaces in code to nbsp', async () => {
    const html = await render({
      markdown: '```js\n  const a = 1\n```',
      platform: 'wechat',
    })

    expect(html).toContain('\u00A0\u00A0')
  })

  it('handles CRLF in code blocks', async () => {
    const html = await render({
      markdown: '```js\r\nconst a = 1\r\n```',
      platform: 'wechat',
    })

    expect(html).not.toContain('\r')
    expect(html).toContain('<br>')
  })

  it('does not render mdnice classic h1 as svg on wechat platform', async () => {
    const html = await render({
      markdown: '# easymd',
      markdownStyle: 'mdnice-classic',
      platform: 'wechat',
    })

    expect(html).toContain('<h1')
    expect(html).toContain('easymd')
    expect(html).not.toContain('<svg')
    expect(html).not.toContain('svg-heading')
  })

  it('keeps mdnice classic h1 consistent with html preview for wysiwyg', async () => {
    const html = await render({
      markdown: '# easymd',
      markdownStyle: 'mdnice-classic',
      platform: 'wechat',
    })

    expect(html).toContain('<h1')
    expect(html).toContain('easymd')
  })

  it('renders an adaptive purple bar and wrapped content in thu-classic h2 for WeChat copy', async () => {
    const html = await render({
      markdown: '## 这是一个足够长的 THU Heading，用于验证标题换行时竖杠仍然跟随标题高度',
      markdownStyle: 'thu-classic',
      platform: 'wechat',
    })

    expect(html).toContain('<h2')
    expect(html).toContain('这是一个足够长的 THU Heading，用于验证标题换行时竖杠仍然跟随标题高度')
    expect(html).toContain('#5c307d')
    expect(html).toContain('data-easymd-inline-bar')
    expect(html).toContain('display:flex')
    expect(html).toContain('align-items:center')
    expect(html).toContain('align-self:stretch')
    expect(html).toContain('min-height:31px')
    expect(html).toContain('min-width:0;flex:1 1 auto')
    expect(html).not.toMatch(/(?:^|[;"])height:\s*31px(?:;|")/u)
    expect(html).toContain('\u00A0')
    expect(html).toMatch(/<h2[^>]*data-easymd-inline-bar[^>]*>.*<span[^>]*>.*THU Heading.*<\/span><\/h2>/)
  })

  it('inserts a real diamond character into thu-classic h3 text for WeChat copy', async () => {
    const html = await render({
      markdown: '### THU Section',
      markdownStyle: 'thu-classic',
      platform: 'wechat',
    })

    expect(html).toContain('<h3')
    expect(html).toContain('THU Section')
    expect(html).toContain('font-size:24px')
    expect(html).toContain('\u25C7')
    expect((html.match(/\u25C7/g) ?? []).length).toBe(1)
    expect(html).toContain('data-easymd-wechat-heading')
    expect(html).not.toContain('display:inline-block;color:#7a4d9a')
    expect(html).not.toContain('rotate(45deg)')
  })

  it('renders thu-classic external links as numbered plain-text references', async () => {
    const html = await render({
      markdown: '[来源](https://example.com/path "正式标题") 和 [来源](https://example.com/path)',
      markdownStyle: 'thu-classic',
      platform: 'wechat',
    })

    expect(html).not.toMatch(/<a\b/)
    expect(html.match(/footnote-ref/g)).toHaveLength(2)
    expect(html.match(/\[1\]/g)).toHaveLength(2)
    expect(html).not.toContain('[2]')
    expect(html).toContain('正式标题')
    expect(html).toContain('https://example.com/path')
    expect(html).toContain('参考资料')
  })
})

describe('katex rendering', () => {
  it('renders math expressions with KaTeX classes', async () => {
    const html = await render({
      markdown: 'Inline $E=mc^2$',
      platform: 'wechat',
    })

    expect(html).toContain('class="katex"')
    expect(html).toContain('katex-html')
  })
})
