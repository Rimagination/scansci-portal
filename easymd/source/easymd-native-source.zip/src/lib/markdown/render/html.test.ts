import { describe, expect, it } from 'vitest'
import { createEditedArticleBlockReference } from './article-blocks'
import { render } from './html'

describe('markdown -> html render (general)', () => {
  it('renders paragraphs as p elements', async () => {
    const html = await render({ markdown: '这是一个段落' })

    expect(html).toContain('<p')
    expect(html).toContain('这是一个段落')
  })

  it('renders headings with correct tags', async () => {
    const html = await render({ markdown: '# 一级标题\n\n## 二级标题' })

    expect(html).toMatch(/<h1[^>]*>.*一级标题.*<\/h1>/)
    expect(html).toMatch(/<h2[^>]*>.*二级标题.*<\/h2>/)
  })

  it('keeps thu-classic h3 diamond as real preview text', async () => {
    const html = await render({
      markdown: '### THU Section',
      markdownStyle: 'thu-classic',
    })

    expect(html).toContain('font-size:24px')
    expect(html).toContain('\u25C7')
    expect((html.match(/\u25C7/g) ?? []).length).toBe(1)
    expect(html).toContain('data-easymd-wechat-heading')
    expect(html).not.toContain('display:inline-block;color:#7a4d9a')
  })

  it('does not add an inline thu-classic h2 bar to html preview', async () => {
    const html = await render({
      markdown: '## THU Heading',
      markdownStyle: 'thu-classic',
    })

    expect(html).toContain('THU Heading')
    expect(html).not.toContain('data-easymd-inline-bar')
    expect(html).not.toContain('width:18px;height:32px;background:#5c307d')
  })

  it('uses the article-inspired style without THU heading decorations', async () => {
    const html = await render({
      markdown: '## Qing Heading\n\n### Qing Subheading',
      markdownStyle: 'qing',
      platform: 'wechat',
    })

    expect(html).toContain('Qing Heading')
    expect(html).toContain('Qing Subheading')
    expect(html).not.toContain('data-easymd-wechat-heading')
    expect(html).not.toContain('\u25C7\u00A0Qing Subheading')
    expect(html).not.toContain('width:18px;height:32px;background:#5c307d')
  })

  it('renders mdnice classic h1 as a normal heading for wysiwyg compatibility', async () => {
    const html = await render({
      markdown: '# easymd',
      markdownStyle: 'mdnice-classic',
    })

    expect(html).toContain('<h1')
    expect(html).toContain('easymd')
    expect(html).not.toContain('<svg')
    expect(html).not.toContain('svg-heading')
  })

  it('renders mdnice classic hr as a green simple divider', async () => {
    const html = await render({
      markdown: '---',
      markdownStyle: 'mdnice-classic',
    })

    expect(html).toContain('<hr')
  })

  it('renders GFM tables correctly', async () => {
    const markdown = '| 列A | 列B |\n|-----|-----|\n| 1 | 2 |'
    const html = await render({ markdown })

    expect(html).toContain('<table')
    expect(html).toContain('<th')
    expect(html).toContain('列A')
    expect(html).toContain('列B')
  })

  it('preserves styled article block HTML for reusable snippets', async () => {
    const markdown = '<section style="margin: 20px 0"><h2 style="color: #111">Title</h2><img src="https://example.com/a.png" alt="demo" style="width: 100%" /></section>'
    const html = await render({ markdown })

    expect(html).toContain('style="margin: 20px 0"')
    expect(html).toContain('style="color: #111"')
    expect(html).toContain('src="https://example.com/a.png"')
    expect(html).toContain('alt="demo"')
    expect(html).toContain('style="width: 100%"')
  })

  it('keeps visual edit font family declarations valid after CSS inlining', async () => {
    const html = await render({
      markdown: '<span style="font-family: Microsoft YaHei, PingFang SC, sans-serif;">CodeMirror 6</span>',
      markdownStyle: 'professional',
    })

    expect(html).toContain('CodeMirror 6')
    expect(html).toContain('font-family: Microsoft YaHei, PingFang SC, sans-serif')
    expect(html).not.toContain('undefined:')
    expect(html).not.toContain('&quot;')
  })

  it('preserves safe animated SVG for reusable interaction snippets', async () => {
    const markdown = '<section style="text-align: center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 48"><g transform="translate(24 24)"><circle cx="0" cy="0" r="12" fill="#fb5a78"><animate attributeName="opacity" values="0.6;1;0.6" dur="1s" repeatCount="indefinite" /></circle><animateTransform attributeName="transform" type="translate" values="24 24;24 18;24 24" dur="1s" repeatCount="indefinite" /></g><text x="48" y="29" font-size="16" font-weight="800" fill="#111827">点赞</text></svg><script>alert(1)</script></section>'
    const html = await render({ markdown })

    expect(html).toContain('<svg')
    expect(html).toContain('<animate')
    expect(html).toContain('<animateTransform')
    expect(html).toContain('repeatCount="indefinite"')
    expect(html).toContain('点赞')
    expect(html).not.toContain('<script')
  })

  it('expands compact article block references before rendering', async () => {
    const html = await render({
      markdown: '@组件[手绘互动按钮](easymd:block/interaction-outline-buttons)',
    })

    expect(html).toContain('<svg')
    expect(html).toContain('点赞')
    expect(html).not.toContain('easymd:block/interaction-outline-buttons')
  })

  it('renders edited article block shortcode sources', async () => {
    const html = await render({
      markdown: createEditedArticleBlockReference(
        'title-center-line',
        '<section><h2 style="color: #22c55e">新的组件标题</h2></section>',
      ),
    })

    expect(html).toContain('新的组件标题')
    expect(html).toContain('#22c55e')
    expect(html).not.toContain('source=')
  })

  it('applies code highlighting classes', async () => {
    const markdown = '```javascript\nconst x = 1\n```'
    const html = await render({ markdown })

    expect(html).toContain('<pre')
    expect(html).toContain('<code')
    expect(html).toContain('hljs')
  })

  it('renders inline math with KaTeX', async () => {
    const html = await render({ markdown: '公式 $E=mc^2$ 很有名' })

    expect(html).toContain('class="katex"')
    expect(html).toContain('katex-mathml')
  })

  it('renders block math with KaTeX', async () => {
    const html = await render({ markdown: '$$\n\\sum_{i=1}^n i\n$$' })

    expect(html).toContain('katex-display')
  })

  it('generates footnote references when enabled', async () => {
    const html = await render({
      markdown: '[示例](https://example.com)',
      enableFootnoteLinks: true,
      platform: 'html',
    })

    expect(html).toContain('footnote-ref')
    expect(html).toContain('[1]')
    expect(html).toContain('References')
  })

  it('keeps thu-classic external links without generated references', async () => {
    const html = await render({
      markdown: '[Example](https://example.com)',
      markdownStyle: 'thu-classic',
      enableFootnoteLinks: true,
      platform: 'html',
    })

    expect(html).toContain('href="https://example.com"')
    expect(html).not.toContain('footnote-ref')
    expect(html).not.toContain('References')
  })

  it('uses link title as reference title while keeping a short marker in body', async () => {
    const html = await render({
      markdown: '杩欓噷闇€瑕佸紩鐢? [鍙傝€?](https://example.com/article "瀹屾暣鏂囩珷鍚嶇О")',
      enableFootnoteLinks: true,
      platform: 'html',
    })

    expect(html).toContain('>鍙傝€?<')
    expect(html).toContain('[1]')
    expect(html).toContain('瀹屾暣鏂囩珷鍚嶇О: ')
    expect(html).not.toContain('鍙傝€?: https://example.com/article')
  })

  it('preserves links without footnotes when disabled', async () => {
    const html = await render({
      markdown: '[示例](https://example.com)',
      enableFootnoteLinks: false,
    })

    expect(html).toContain('href="https://example.com"')
    expect(html).not.toContain('footnote-ref')
  })

  it('reuses footnote id for duplicate links', async () => {
    const html = await render({
      markdown: '[链接1](https://example.com) 和 [链接2](https://example.com)',
      enableFootnoteLinks: true,
      platform: 'html',
    })

    const matches = html.match(/\[1\]/g)
    expect(matches?.length).toBe(2)
    expect(html).not.toContain('[2]')
  })

  it('adds target blank when openLinksInNewWindow is true', async () => {
    const html = await render({
      markdown: '[外链](https://example.com)',
      openLinksInNewWindow: true,
      enableFootnoteLinks: false,
    })

    expect(html).toContain('target="_blank"')
    expect(html).toContain('rel="noreferrer noopener"')
  })

  it('hides YAML frontmatter from the article preview by default', async () => {
    const markdown = '---\ntitle: 测试标题\nauthor: 作者\n---\n\n正文内容'
    const html = await render({ markdown })

    expect(html).not.toContain('<table')
    expect(html).not.toContain('测试标题')
    expect(html).not.toContain('author')
    expect(html).toContain('正文内容')
  })

  it('renders YAML frontmatter when explicitly requested', async () => {
    const markdown = '---\ntitle: 测试标题\nauthor: 作者\n---\n\n正文内容'
    const html = await render({ markdown, showFrontmatter: true })

    expect(html).toContain('<table')
    expect(html).toContain('title')
    expect(html).toContain('测试标题')
    expect(html).toContain('author')
  })

  it('handles empty input', async () => {
    const html = await render({ markdown: '' })

    expect(html).toBeDefined()
  })

  it('renders GitHub alerts', async () => {
    const markdown = '> [!NOTE]\n> 这是一个提示'
    const html = await render({ markdown })

    expect(html).toContain('markdown-alert')
    expect(html).toContain('markdown-alert-note')
    expect(html).toContain('markdown-alert-title')
    expect(html).toContain('Note')
    expect(html).not.toContain('[!NOTE]')
  })

  it('converts div to section for platform compatibility', async () => {
    const markdown = '> [!NOTE]\n> 这是一个提示'
    const html = await render({ markdown })

    expect(html).toContain('<section')
    expect(html).toContain('class="markdown-alert')
    expect(html).not.toMatch(/<div[^>]*class="markdown-alert/)
  })

  it('wraps text nodes with span when mixed with inline elements', async () => {
    const html = await render({ markdown: '**Markdown 渲染**：将 Markdown 转换为 HTML' })

    expect(html).toContain('<strong')
    expect(html).toContain('Markdown 渲染')
    expect(html).toMatch(/<span[^>]*>：将 Markdown 转换为 HTML<\/span>/)
  })

  it('wraps text in pure text paragraph', async () => {
    const html = await render({ markdown: '纯文本段落' })

    expect(html).toContain('<p')
    expect(html).toMatch(/<p[^>]*><span[^>]*>纯文本段落<\/span><\/p>/)
  })

  it('wraps text in pure text list item', async () => {
    const html = await render({ markdown: '- 语法高亮与更好的代码评审体验' })

    expect(html).toContain('<li')
    expect(html).toMatch(/<li[^>]*><span[^>]*>语法高亮与更好的代码评审体验<\/span><\/li>/)
  })

  it('wraps text in list items with mixed content', async () => {
    const html = await render({ markdown: '- **功能**：这是说明文字' })

    expect(html).toContain('<li')
    expect(html).toContain('<strong')
    expect(html).toMatch(/<span[^>]*>：这是说明文字<\/span>/)
  })

  it('does not wrap text inside nested inline elements', async () => {
    const html = await render({ markdown: '*斜体**粗体**后续*' })

    expect(html).toContain('<em')
    expect(html).toContain('<strong')
    expect(html).not.toMatch(/<em[^>]*><span/)
  })

  it('wraps text even when br element is present', async () => {
    const html = await render({ markdown: '第一行  \n第二行' })

    expect(html).toContain('<br')
    expect(html).toMatch(/<span[^>]*>第一行<\/span>/)
    expect(html).toMatch(/<span[^>]*>\s*第二行<\/span>/)
  })
})

describe('platform-specific rendering', () => {
  it('renders for zhihu platform without errors', async () => {
    const html = await render({
      markdown: '# 标题\n\n[链接](https://example.com)',
      platform: 'zhihu',
    })

    expect(html).toContain('标题')
  })

  it('renders for zhihu code blocks without errors', async () => {
    const html = await render({
      markdown: '# 标题\n\n```js\ncode\n```',
      platform: 'zhihu',
    })

    expect(html).toContain('标题')
    expect(html).toContain('code')
  })
})

describe('i18n support', () => {
  it('uses custom referenceTitle in footnotes section', async () => {
    const html = await render({
      markdown: '[链接](https://example.com)',
      enableFootnoteLinks: true,
      platform: 'html',
      referenceTitle: '参考链接',
    })

    expect(html).toContain('参考链接')
    expect(html).not.toContain('References')
  })

  it('uses custom referenceTitle for wechat platform', async () => {
    const html = await render({
      markdown: '[链接](https://example.com)',
      platform: 'wechat',
      referenceTitle: '参考链接',
    })

    expect(html).toContain('参考链接')
    expect(html).not.toContain('References')
  })

  it('uses custom footnoteLabel for GFM footnotes', async () => {
    const html = await render({
      markdown: '文本[^1]\n\n[^1]: 脚注内容',
      footnoteLabel: '脚注',
    })

    expect(html).toContain('脚注')
    expect(html).not.toContain('Footnotes')
  })
})
