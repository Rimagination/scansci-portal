import { createRequire } from 'node:module'
import { readFileSync, readdirSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import tsconfigPaths from 'vite-tsconfig-paths'
import { markdownPlugin } from './scripts/vite'

const require = createRequire(import.meta.url)
const postcss = createRequire(require.resolve('vite/package.json'))('postcss')
const sourceRoot = fileURLToPath(new URL('./', import.meta.url))
const targetRoot = process.env.SCANSCI_EDITOR_OUTPUT || 'D:/scansci/scansci-portal-repo/easymd/native'
const packageStore = resolve(sourceRoot, 'node_modules/.pnpm')
function workerParser(name: string) {
  const folder = readdirSync(packageStore).find(folder => folder.startsWith(`${name}@`))
  if (!folder) throw new Error(`The existing dependency ${name} is unavailable`)
  return resolve(packageStore, folder, 'node_modules', name, 'index.js')
}

export default defineConfig({
  root: sourceRoot,
  base: '/easymd/native/',
  publicDir: false,
  envDir: 'D:/scansci/scansci-portal-repo/.local/portal-tools/native-env',
  define: {
    'import.meta.env.VITE_API_URL': JSON.stringify('/easymd'),
    'import.meta.env.VITE_APP_URL': JSON.stringify('https://www.scansci.com/easymd'),
  },
  plugins: [
    tsconfigPaths({ projects: ['./tsconfig.json'] }),
    tailwindcss(),
    markdownPlugin(),
    react(),
    {
      name: 'scansci-editor-css',
      generateBundle(_, bundle) {
        this.emitFile({ type: 'asset', fileName: 'blur-mask.svg', source: readFileSync(resolve(sourceRoot, 'public/blur-mask.svg')) })
        for (const asset of Object.values(bundle)) {
          if (asset.type !== 'asset' || !asset.fileName.endsWith('.css')) continue
          const css = postcss.parse(String(asset.source))
          css.walkDecls((declaration) => {
            declaration.value = declaration.value.replace(/\/blur-mask\.svg/g, '/easymd/native/blur-mask.svg')
          })
          css.walkRules((rule) => {
            for (let parent = rule.parent; parent; parent = parent.parent) {
              if (parent.type === 'atrule' && /keyframes$/i.test(parent.name)) return
            }
            rule.selectors = rule.selectors.map((selector) => {
              const scoped = selector
                .replace(/:root|:host/g, '#easymdRoot')
                .replace(/^(html|body)$/, '#easymdRoot')
                .replace(/^\.dark$/, 'html.dark #easymdRoot')
              return scoped.includes('#easymdRoot') ? scoped : `#easymdRoot ${scoped}`
            })
          })
          asset.source = css.toString()
        }
      },
    },
  ],
  resolve: {
    alias: {
      // These parsers also run in a Web Worker, where browser DOM exports cannot run.
      'decode-named-character-reference': workerParser('decode-named-character-reference'),
      'hast-util-from-html-isomorphic': workerParser('hast-util-from-html-isomorphic'),
    },
  },
  worker: { format: 'es', plugins: () => [tsconfigPaths({ projects: ['./tsconfig.json'] })] },
  build: {
    outDir: targetRoot,
    emptyOutDir: true,
    manifest: true,
    rollupOptions: {
      input: { scansci: `${sourceRoot}src/scansci-entry.tsx` },
      preserveEntrySignatures: 'strict',
    },
  },
})
