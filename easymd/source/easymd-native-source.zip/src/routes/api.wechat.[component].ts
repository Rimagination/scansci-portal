import { createFileRoute } from '@tanstack/react-router'
import { wechatDraftMiddleware } from '@/lib/middleware/wechat-draft'
import { handlers } from '@/lib/wechat-draft/http/component'

export const Route = createFileRoute('/api/wechat/component')({
  server: { middleware: [wechatDraftMiddleware], handlers },
})
