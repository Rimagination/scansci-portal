import { createFileRoute } from '@tanstack/react-router'
import { wechatDraftMiddleware } from '@/lib/middleware/wechat-draft'
import { handlers } from '@/lib/wechat-draft/http/account'

export const Route = createFileRoute('/api/wechat/account')({
  server: { middleware: [wechatDraftMiddleware], handlers },
})
